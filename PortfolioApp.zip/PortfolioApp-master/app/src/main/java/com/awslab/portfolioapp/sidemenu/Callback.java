package com.awslab.portfolioapp.sidemenu;

public interface Callback {

    void onSideMenuItemClick(int i);

}
