package com.awslab.portfolioapp.portfolio;

public interface PortfolioCallback {

    void onPortfolioItemClick(int pos);

}
