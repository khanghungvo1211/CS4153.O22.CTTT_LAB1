package com.example.ex_4;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button buttonShowAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.edit_text_input);
        buttonShowAlert = findViewById(R.id.button_show_alert);

        // Set up key listener for the EditText
        editText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // Check if the enter key was pressed
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                    // Display the entered text in an AlertDialog
                    showAlertDialog(editText.getText().toString());
                    return true; // Consume the event
                }
                return false; // Let the event be handled normally
            }
        });

        // Set up click listener for the button
        buttonShowAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Display the entered text in an AlertDialog
                showAlertDialog(editText.getText().toString());
            }
        });
    }

    // Method to display an AlertDialog with the given message
    private void showAlertDialog(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); // Dismiss the dialog when OK is clicked
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show(); // Show the AlertDialog
    }
}
